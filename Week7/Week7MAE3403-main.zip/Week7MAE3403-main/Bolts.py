#a ScrewThread class
class ScrewThread():
    #this is a constructor
    def __init__(self, system, handed,diam,pitch,lead):
        #fields/properties
        self.sys=system
        self.hand=handed
        self.dia=diam
        self.pitch=pitch
        self.lead=lead

    #this is a method/function of the class
    def PrintProps(self):
        print('System=',self.sys)
        print('Handedness=',self.hand)
        print('Diameter=',self.dia)
        print('Pitch=',self.pitch)
        print('Lead=', self.lead)

#a Bolt class
class Bolt():
    #constructor
    def __init__(self, thread, grade, headtype, length):
        '''
        Constructor of Bolt class
        :param thread: property of Bolt; an object of type ScrewThread
        :param grade: property of Bolt
        :param headtype: property of Bolt
        :param length: Property of Bolt
        '''
        self.thread=thread
        self.grade=grade
        self.headtype=headtype
        self.length=length

    def PrintProps(self):
        print('Bolt properties:')
        print('Grade=',self.grade)
        print('Head Type=',self.headtype)
        print('Length=',self.length)
        print('Thread properties:')
        self.thread.PrintProps()

def main():
    mybolt=Bolt(ScrewThread('SAE','right','0.25 in', '1/20 in', '1/20 in'), 5, 'socket', 1.0)
    mybolt.PrintProps()

main()