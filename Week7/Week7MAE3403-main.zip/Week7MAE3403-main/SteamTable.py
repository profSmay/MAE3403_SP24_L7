import numpy as np
from scipy.interpolate import griddata

def main():
    tcol, hcol,scol,pcol=np.loadtxt('superheated_water_table.txt', skiprows=1, unpack=True)

    pval=90 #kpa
    tval=250 #C

    h=float(griddata((tcol,pcol),hcol,(tval,pval)))
    s=float(griddata((tcol,pcol),scol,(tval,pval)))
    t=float(griddata((hcol,pcol),tcol,(h+500,pval)))
    print(h,s,t)

main()