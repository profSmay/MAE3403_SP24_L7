import math

class Circle():
    def __init__(self, xcenter=0, ycenter=0, radius=1):
        self.x=xcenter
        self.y=ycenter
        self.r=radius

    def Area(self):
        return math.pi*self.r**2

    def Circum(self):
        return math.pi*2*self.r

def main():
    c1=Circle(1,2,3)
    c2=Circle(0,0,4)
    c3=Circle()
    print('c1 has area={:0.3f} and circum={:0.3f}'.format(c1.Area(),c1.Circum()))
    print('c2 has area={:0.3f} and circum={:0.3f}'.format(c2.Area(),c2.Circum()))
    print('c3 has area={:0.3f} and circum={:0.3f}'.format(c3.Area(),c3.Circum()))

main()